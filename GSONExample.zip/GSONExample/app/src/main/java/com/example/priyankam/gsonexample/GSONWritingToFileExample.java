package com.example.priyankam.gsonexample;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class GSONWritingToFileExample extends AppCompatActivity {

    Context context;
    String fileName = "MyFile";
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gsonwriting_to_file_example);
        context = getApplicationContext();
        textView = (TextView) findViewById(R.id.textView);

        Country countryObj = new Country();
        countryObj.setName("India");
        countryObj.setPopulation(500000);
        List<String> listOfStates = new ArrayList<String>();
        listOfStates.add("Delhi");
        listOfStates.add("Odisha");

        countryObj.setListOfStates(listOfStates);
        Gson gson = new Gson();

        // convert java object to JSON format,
        // and returned as JSON formatted string
        String json = gson.toJson(countryObj);

        try {

            WriteJSONInAssets(json);
            textView.setText(ReadJsonFromFile(context));

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(json);

    }

    private String ReadJsonFromFile(Context context) {
        // READ a file from the Internal Storage
        BufferedReader input = null;
        File file = null;
        try {
            file = new File(getFilesDir(), fileName); // Pass getFilesDir() and "MyFile" to read file

            input = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            String line;
            StringBuffer stringBuffer = new StringBuffer();
            while ((line = input.readLine()) != null) {
                stringBuffer.append(line);
            }
            Log.d("READ FILE", stringBuffer.toString());
            return stringBuffer.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void WriteJSONInAssets(String json) {

        // Create and write a file in the Internal Storage
        String content = json;
        FileOutputStream outputStream = null;
        try {
            outputStream = openFileOutput(fileName, Context.MODE_PRIVATE);
            outputStream.write(content.getBytes());
            outputStream.close();
            Log.d("Write FILE", content.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
