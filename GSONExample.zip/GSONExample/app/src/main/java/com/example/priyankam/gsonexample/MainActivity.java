package com.example.priyankam.gsonexample;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Context context;
    ArrayList<String> statesListValue = new ArrayList<String>();
    private ArrayAdapter<String> listAdapter;

    public static String loadJSONFromAsset(Context context) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            InputStream is = context.getAssets().open("CountryGSON.json");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));


            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
            }

            bufferedReader.close();
            return stringBuilder.toString();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getApplicationContext();
        TextView text1 = (TextView) findViewById(R.id.text1);
        TextView text2 = (TextView) findViewById(R.id.text2);
        ListView listView = (ListView) findViewById(R.id.list);

        Gson gson = new Gson();

        System.out.println("Reading JSON from a file");
        System.out.println("----------------------------");

        //BufferedReader br = new BufferedReader(new FileReader("http://beta.json-generator.com/api/json/get/Eyob7l_PZ"));

        //convert the json string back to object
        //   Country countryObj = gson.fromJson(br, Country.class);

        Country countryObj = gson.fromJson(loadJSONFromAsset(context), Country.class);

        System.out.println("Name Of Country: " + countryObj.getName());
        text1.setText("Name Of Country: " + countryObj.getName());

        System.out.println("Population: " + countryObj.getPopulation());
        text2.setText("Population: " + countryObj.getPopulation());
        System.out.println("States are :");


        List<String> listOfStates = countryObj.getListOfStates();
        for (int i = 0; i < listOfStates.size(); i++) {
            System.out.println(listOfStates.get(i));
            statesListValue.addAll(Arrays.asList(listOfStates.get(i)));
        }
        listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, statesListValue);
        listView.setAdapter(listAdapter);

    }
}
